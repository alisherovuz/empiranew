import json
from pathlib import Path
from playwright.sync_api import sync_playwright

OUT=Path('/workspace/empira-audit')
BASE='http://127.0.0.1:8000/design-prototype/'
inventory=json.loads((OUT/'inventory.json').read_text())
results=[]
def record(name,**kwargs):
    r={'name':name,**kwargs};results.append(r);print(json.dumps(r,ensure_ascii=False),flush=True)
    (OUT/'flow-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))

with sync_playwright() as p:
    b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    page=b.new_page(viewport={'width':1280,'height':720})
    page.route('**/api/scan',lambda r:r.fulfill(status=503,content_type='application/json',body='{"status":"error"}'))
    errs=[]
    page.on('pageerror',lambda e:errs.append(str(e)))
    good=0
    for topic in inventory['topics']:
        errs.clear()
        page.goto(BASE+'topic/index.html?mavzu='+topic['slug'],wait_until='domcontentloaded')
        assert page.locator('h1.title').inner_text()==topic['title']
        assert page.locator('.lab-card').count()==len(topic['labs'])
        assert not errs,errs
        good+=1
    record('all-topic-pages',passed=good,total=len(inventory['topics']))
    page.goto(BASE+'home/index.html',wait_until='load')
    page.locator('a.grade[href$="sinf=8"]').click()
    page.locator('[data-now]').click()
    assert 'laboratoriya-ishi-om-qonunini-organish' in page.url
    page.locator('[data-main-cta]').click()
    page.wait_for_selector('[data-loading]',state='hidden')
    assert page.url.endswith('lab=om-qonuni')
    page.locator('[data-back]').click()
    assert 'laboratoriya-ishi-om-qonunini-organish' in page.url
    record('manual-ohm-and-back',passed=True)
    page.goto(BASE+'class-plan/index.html?sinf=8&hafta=18')
    record('week-18-current-row',text=page.locator('[data-now]').inner_text(),href=page.locator('[data-now]').get_attribute('href'))
    page.locator('[data-toggle-all]').click()
    record('chapter-toggle-all',expanded=page.locator('.chapter__head[aria-expanded="true"]').count())
    page.goto(BASE+'class-plan/index.html?sinf=8#bob-5')
    record('chapter-deep-link',expanded=page.locator('#bob-5 .chapter__head').get_attribute('aria-expanded'))
    for grade in [6,7,9,10,11]:
        page.goto(BASE+f'class-plan/index.html?sinf={grade}')
        assert page.locator('[data-empty]').is_visible()
    record('other-grade-empty-states',passed=5)
    page.goto(BASE+'home/index.html?davom=1')
    page.locator('[data-continue]').click()
    record('legacy-continue-link',url=page.url,title=page.locator('h1.title').inner_text())
    page.goto(BASE+'scan/index.html?taqdimot=1')
    page.locator('[data-pick="laboratoriya-ishi-om-qonunini-organish"]').click()
    page.locator('[data-input-upload]').set_input_files('/workspace/empiratest/brand/logo-flask-e/png/app-icon-180.png')
    page.wait_for_selector('[data-state="result"]')
    record('presenter-upload',topic=page.locator('[data-r-topic]').inner_text(),href=page.locator('.result__cta').get_attribute('href'))
    page.goto(BASE+'scan/index.html?taqdimot=0')
    page.locator('[data-input-upload]').set_input_files({'name':'note.txt','mimeType':'text/plain','buffer':b'test'})
    assert page.locator('[data-alert]').is_visible()
    record('invalid-upload',passed=True,text=page.locator('[data-alert-text]').inner_text())
    page.locator('[data-camera-start]').click()
    page.wait_for_function("document.querySelector('[data-alert-text]').textContent.includes('Kamera ochilmadi')")
    record('camera-unavailable',passed=True)
    page.locator('[data-input-upload]').set_input_files('/workspace/empiratest/brand/logo-flask-e/png/app-icon-180.png')
    page.wait_for_selector('[data-state="notfound"]')
    record('api-unavailable-mocked',passed=True,text=page.locator('.view--notfound .hint').inner_text())
    page.locator('.view--notfound [data-rescan]').click()
    assert page.locator('[data-state]').get_attribute('data-state')=='idle'
    record('scanner-retry',passed=True)
    for section in [19,24,18]:
        topic=next(t for t in inventory['topics'] if t['n']==section)
        fixture={'status':'found','topic':{'slug':topic['slug'],'title':topic['title']},'labs':[{'slug':l,'title':l} for l in topic['labs']]}
        page.unroute('**/api/scan')
        page.route('**/api/scan',lambda r:r.fulfill(status=200,content_type='application/json',body=json.dumps(fixture)))
        page.goto(BASE+'scan/index.html?taqdimot=0')
        page.locator('[data-input-upload]').set_input_files('/workspace/empiratest/brand/logo-flask-e/png/app-icon-180.png')
        page.wait_for_selector('[data-state="result"]')
        record('scanner-response-mocked',section=section,labCount=len(topic['labs']),href=page.locator('.result__cta').get_attribute('href'),text=page.locator('.result__cta').inner_text())
    b.close()
