import json
from pathlib import Path
from playwright.sync_api import sync_playwright

OUT = Path('/workspace/empira-audit')
BASE = 'http://127.0.0.1:8000/design-prototype/'
inventory = json.loads((OUT / 'inventory.json').read_text())
results = {'labs': [], 'flows': [], 'screens': []}

with sync_playwright() as p:
    browser = p.chromium.launch(executable_path='/usr/bin/chromium', headless=True,
        args=['--no-sandbox', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'])
    context = browser.new_context(viewport={'width':1280,'height':720})
    page = context.new_page()
    errors = []
    page.on('pageerror', lambda e: errors.append(str(e)))
    # Never send an image to a paid service during this audit.
    page.route('**/api/scan', lambda route: route.fulfill(status=503, content_type='application/json', body='{"status":"error","error":"audit_no_external_api"}'))
    for lab_id in inventory['labIds']:
        errors.clear()
        result = {'id':lab_id}
        try:
            page.goto(BASE + 'lab/index.html?lab=' + lab_id, wait_until='load')
            page.wait_for_selector('[data-loading]', state='hidden', timeout=20000)
            assert not page.locator('[data-fallback]').is_visible(), 'WebGL fallback visible'
            page.locator('[data-run]').click()
            page.wait_for_function("document.querySelector('[data-runs-body]').children.length === 1", timeout=45000)
            row = page.locator('[data-runs-body]').inner_text()
            assert row.strip() and 'NaN' not in row and 'undefined' not in row
            assert not errors, errors
            result.update(passed=True, row=row)
        except Exception as e:
            result.update(passed=False, error=str(e), page_errors=list(errors))
        results['labs'].append(result)
        (OUT / 'browser-results.json').write_text(json.dumps(results, ensure_ascii=False, indent=2))
        print(json.dumps(result, ensure_ascii=False), flush=True)

    for width,height in [(1280,720),(800,1024),(390,844),(375,667)]:
        page.set_viewport_size({'width':width,'height':height})
        for name,url in [
            ('home','home/index.html'),
            ('curriculum','class-plan/index.html?sinf=8&ochiq=hammasi'),
            ('topic-ohm','topic/index.html?mavzu=laboratoriya-ishi-om-qonunini-organish'),
            ('scanner-result','scan/index.html?holat=natija&mavzu=laboratoriya-ishi-om-qonunini-organish'),
            ('lab-ohm','lab/index.html?lab=om-qonuni')]:
            errors.clear()
            page.goto(BASE+url,wait_until='load')
            if name=='lab-ohm':
                page.wait_for_selector('[data-loading]',state='hidden')
                for voltage in [4,6,8,10]:
                    page.locator('[data-ctl="U"]').fill(str(voltage))
                    page.locator('[data-run]').click()
                    page.wait_for_function('(n)=>document.querySelector("[data-runs-body]").children.length===n',arg=(voltage-2)//2,timeout=15000)
                assert 'Rₒ‘ᵣₜ' in page.locator('[data-readouts]').inner_text()
                assert page.locator('[data-step].is-done').count()==3
            overflow=page.evaluate('document.documentElement.scrollWidth > innerWidth')
            result={'screen':name,'width':width,'height':height,'horizontalOverflow':overflow,'errors':list(errors),'soraLoaded':page.evaluate("document.fonts.check('16px Sora')")}
            if name=='curriculum':result.update(topics=page.locator('.topic').count(),chapters=page.locator('.chapter').count(),soon=page.locator('.tag--soon').count())
            if name=='scanner-result':result['cta']=page.locator('.result__cta').get_attribute('href')
            if name=='lab-ohm':result['rows']=page.locator('[data-runs-body]').inner_text()
            if width in [1280,390,375]:
                path=OUT/f'{name}-{width}x{height}.png'
                page.screenshot(path=str(path),full_page=name=='curriculum')
                result['screenshot']=str(path)
            results['screens'].append(result)
            print(json.dumps(result,ensure_ascii=False),flush=True)
            (OUT / 'browser-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
    browser.close()
