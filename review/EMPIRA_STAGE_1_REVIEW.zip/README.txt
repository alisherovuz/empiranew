Empira Stage 1 review package

Start with EMPIRA_NEXT_BUILD_PLAN.md.
Screenshots show the existing MVP before implementation.
Audit JSON contains local validation results; scripts reference the original workspace paths.
No product code changes are included. Stage 2 awaits approval.
